Put meditation.mp3 and bell.mp3 in this folder.
